﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hospital_SMS
{
    public partial class Diagnosis : Form
    {
        public Diagnosis()
        {
            InitializeComponent();
            DisplayDiagnosis();
        }

        readonly SqlConnection con = new SqlConnection(connectionString: @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Laptop Outlet\Documents\Hosital MS.mdf"";Integrated Security=True;Connect Timeout=30;Encrypt=False");

        private void DisplayDiagnosis()
        {
            try
            {
                con.Open();
                string Query = "Select * from Diagnosis";
                SqlDataAdapter sda = new SqlDataAdapter(Query, con);
                SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sda);
                var ds = new DataSet();
                sda.Fill(ds);
                dataGridView3.DataSource = ds.Tables[0];
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        void DisplayPatientId()
        {
            string sql = "select * from Patient";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader rdr;
            try
            {
                con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("PId ", typeof(int));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                comboBox1.ValueMember = "PId";
                comboBox1.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }


        private void Crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Addbtn_Click(object sender, EventArgs e)
        {

            try
            {
                if (textBox1.Text == " " || comboBox1.Text == " " || textBox2.Text == " " || textBox3.Text == " " || textBox4.Text == " " || textBox5.Text == " ")

                {
                    MessageBox.Show("Missing information");
                }
                else
                {
                    con.Open();
                    string query = "insert into Diagnosis Values('" + textBox1.Text + "', '" + comboBox1.Text + "', '" + textBox2.Text + "', '" + textBox3.Text + "', '" + textBox4.Text + "', '" + textBox5.Text + "')";
                    if (!System.Text.RegularExpressions.Regex.IsMatch(textBox2.Text, @"^[a-zA-Z ]+$"))
                    {
                        MessageBox.Show("Patient Name only use Latters.");
                        return;
                    }

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record entered Successfully");
                    DisplayDiagnosis();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == " " || comboBox1.Text == " " || textBox2.Text == " " || textBox3.Text == " " || textBox4.Text == " " || textBox5.Text == " ")

                {
                    MessageBox.Show("Missing information");
                }
                else
                {
                    con.Open();
                    string query = "update Diagnosis set PatientId=@PId, PatientName=@PName, Symptoms=@Symptoms, DiagnosticTest=@DiagnosticTest, Medicines=@Medicines where DId = @DId";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@PId", comboBox1.Text);
                    cmd.Parameters.AddWithValue("@PName", textBox2.Text);
                    cmd.Parameters.AddWithValue("@Symptoms", textBox3.Text);
                    cmd.Parameters.AddWithValue("@DiagnosticTest", textBox4.Text);
                    cmd.Parameters.AddWithValue("@Medicines", textBox5.Text);
                    cmd.Parameters.AddWithValue("@DId", textBox1.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record Update Successfully");
                    DisplayDiagnosis();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void DelBtn_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == " ")
                {
                    MessageBox.Show("Enter the Diagnosis Id");
                }
                else
                {
                    con.Open();
                    string query = "delete from Diagnosis where DId='" + textBox1.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record Delete Successfully");
                    DisplayDiagnosis();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void HomeBtn_Click(object sender, EventArgs e)
        {
            Home obj = new Home();
            obj.Show();
            this.Hide();
        }

        private void ResetBtn_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            comboBox1.Text = " ";
            textBox2.Text = " ";
            textBox3.Text = " ";
            textBox4.Text = " ";
            textBox5.Text = " ";
        }

        private void dataGridView3_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                textBox1.Text = dataGridView3.SelectedRows[0].Cells[0].Value.ToString();
                comboBox1.Text = dataGridView3.SelectedRows[0].Cells[1].Value.ToString();
                textBox2.Text = dataGridView3.SelectedRows[0].Cells[2].Value.ToString();
                textBox3.Text = dataGridView3.SelectedRows[0].Cells[3].Value.ToString();
                textBox4.Text = dataGridView3.SelectedRows[0].Cells[4].Value.ToString();
                textBox5.Text = dataGridView3.SelectedRows[0].Cells[5].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void Diagnosis_Load(object sender, EventArgs e)
        {
            DisplayPatientId();
        }

        string Pname;

        void DisplayPatientName()
        {

            try
            {
                con.Open();
                string ss = "select * from Patient where PatientId = " + comboBox1.SelectedValue.ToString();

                SqlCommand cmd = new SqlCommand(ss, con);
                DataTable dt = new DataTable();
                SqlDataAdapter ada = new SqlDataAdapter(cmd);
                ada.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    Pname = dr["PatientName"].ToString();
                    textBox2.Text = Pname;
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            insertToFile(dataGridView3.Rows[e.RowIndex]);
        }

        public void insertToFile(DataGridViewRow selectedRow)
        {
            string filePath = @"C:\Users\Laptop Outlet\Desktop\final project\Hospital SMS\Hospital SMS\DiagnosisInfo.txt";

            using (StreamWriter sw = new StreamWriter(filePath))
            {
                sw.WriteLine("Diagnosis Information");

                foreach (DataGridViewCell cell in selectedRow.Cells)
                {
                    sw.WriteLine($"{cell.OwningColumn.HeaderText} : {cell.Value}");
                }

                sw.WriteLine("-------------------------------------------------------------------------------------------");
            }

            MessageBox.Show("Diagnosis information saved to text file.");
        }
    }
}