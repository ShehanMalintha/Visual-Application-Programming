﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_SMS
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            UserName.Text = " ";
            Password.Text = " ";
        }

        private void Crossbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Loginbtn_Click(object sender, EventArgs e)
        {
            if (UserName.Text == "" && Password.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else if(UserName.Text == "Admin" && Password.Text == "Admin123")
            {
                Home obj = new Home();
                obj.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Your username or password are Incorrect");
            }
        }
    }
}
